Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, http://extract.bbbike.org
 by Geofabrik, http://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Thu Oct 27 12:44:31 UTC 2016
GPS rectangle coordinates (lng,lat): 
Script URL: 
Name of area: 

We appreciate any feedback, suggestions and a donation! You can support us via
PayPal, Flattr or bank wire transfer: http://www.BBBike.org/community.html

thanks, Wolfram Schneider

--
Your Cycle Route Planner: http://www.BBBike.org
BBBike Map Compare: http://bbbike.org/mc
